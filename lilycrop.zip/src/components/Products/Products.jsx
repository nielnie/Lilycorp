import React from "react";
import {Grid} from '@material-ui/core';
import Product from './Product/Product'



// const products =[
//     {id:1, name:'Giselinde', description:'plants', price:'5€'},
//     {id:2, name:'Ursula', description:'plants', price:'5€'},
//     {id:3, name:'Nick', description:'pot', price:'5€'},
//     {id:1, name:'Giselinde', description:'plants', price:'5€'},
//     {id:2, name:'Ursula', description:'plants', price:'5€'},
//     {id:3, name:'Nick', description:'pot', price:'5€'},
//     {id:1, name:'Giselinde', description:'plants', price:'5€'},
//     {id:2, name:'Ursula', description:'plants', price:'5€'},
//     {id:3, name:'Nick', description:'pot', price:'5€'},
//     {id:1, name:'Giselinde', description:'plants', price:'5€'},
//     {id:2, name:'Ursula', description:'plants', price:'5€'},
//     {id:3, name:'Nick', description:'pot', price:'5€'},
    

// ];

const Products = ({}) => {
    return (

        <main>
        {/* <Grid container justify="center" spacing={5}>
            {products.map((product) => (
                <Grid item key ={product.id} xs={12} s={6} md={4} lg={4}>
                    <Product product={product} />
                    </Grid>
            ))}

        </Grid> */}

    </main>
    )

    


}

export default Products


