import React from 'react';
import {Container, Typography, Button, Grid, Card, CardContent, CardActions} from'@material-ui/core';

const CartItem = ({product, deleteFromCart}) => {
  return (
    <Card >
        
        <CardContent>
                <Typography variant = "h5" gutterBottom>
                    {product.name}  
                </Typography>
                <Typography variant = "h5" >
                     {product.price}  €
                </Typography>
                <Typography>
                    Anzahl: {product.count}
                </Typography>
        </CardContent>
        <CardActions>
            <div>
                
                <Button color="secondary" onClick={() => deleteFromCart(product.id)}>
                    löschen
                </Button>
            </div>
        </CardActions>
        
    </Card>
  )
}

export default CartItem